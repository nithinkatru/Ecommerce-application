package com.example.myproject;

public class NextActivity {
}
